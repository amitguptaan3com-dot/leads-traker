

let myleads = JSON.parse(localStorage.getItem('myleads')) || []


const inputEl = document.getElementById('text-el')
const ulel = document.getElementById('ul-el')
const deletes = document.getElementById('del')

const inputbtn  = document.getElementById('save')

inputbtn.addEventListener('click',() => {
    console.log(inputEl.value)
    myleads.push(inputEl.value)
    localStorage.setItem('myleads',JSON.stringify(myleads))
    render()
    inputEl.value = ''
})

function render(){
    ulel.innerHTML = ''
    for (let i = 0; i < myleads.length; i++){
        ulel.innerHTML += `<li><a href="${myleads[i]}" target="_blank"> ${myleads[i]} </a></li>`
        
}}

deletes.addEventListener('dblclick',() => {
    localStorage.clear()
    myleads = []
    render()
})

if(myleads.length){
    render()
}
